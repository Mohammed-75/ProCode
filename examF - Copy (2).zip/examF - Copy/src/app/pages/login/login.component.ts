import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

import { LoginService } from 'src/app/services/login.service';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {



  //styling purpose
  @ViewChild('container') container: ElementRef;

  signIn() {
    this.container.nativeElement.classList.remove('right-panel-active');
  }

  signUp() {
    this.container.nativeElement.classList.add('right-panel-active');
  }

  loginData = {
    username: '',
    password: '',
  };
 
  public user = {
    username: '',
    password: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
  };
  constructor(
    private userService: UserService,
    private snack: MatSnackBar,
    private login: LoginService,
    private router: Router
  ) {}

  ngOnInit(): void {}



  //login purpose
  onsubmit() {
    console.log('login btn clicked');

    if (
      this.loginData.username.trim() == '' ||
      this.loginData.username == null
    ) {
      this.snack.open('Username is required !! ', '', {
        duration: 3000,
      });
      return;
    }

    if (
      this.loginData.password.trim() == '' ||
      this.loginData.password == null
    ) {
      this.snack.open('Password is required !! ', '', {
        duration: 3000,
      });
      return;
    }
    //request to server to generate token
    this.login.generateToken(this.loginData).subscribe(
      (data: any) => {
        console.log('success');
        console.log(data);

        //login...
        this.login.loginUser(data.token);

        this.login.getCurrentUser().subscribe((user: any) => {
          this.login.setUser(user);
          console.log(user);
          //redirect ...ADMIN: admin-dashboard
          //redirect ...NORMAL:normal-dashboard
          if (this.login.getUserRole() == 'ADMIN') {
            //admin dashboard
            // window.location.href = '/admin';
            this.router.navigate(['admin']);
            this.login.loginStatusSubject.next(true);
          } else if (this.login.getUserRole() == 'NORMAL') {
            //normal user dashbaord
            // window.location.href = '/user-dashboard';
            this.router.navigate(['user-dashboard/0']);
            this.login.loginStatusSubject.next(true);
          } else {
            this.login.logout();
          }
        });
      },
      (error) => {
        console.log('Error !');
        console.log(error);
        this.snack.open('Invalid Credentials !! Try again', '', {
          duration: 3000,
        });
      }
    );
  }
  
//register purpose
  formSubmit() {
    console.log(this.user);
    // if (this.user.username == '' || this.user.username == null)
    if (
      this.user.username == '' ||
      this.user.username == null ||
      this.user.password == '' ||
      this.user.password == null ||
      this.user.password == ''||
      this.user.firstName == null ||
      this.user.firstName == ''||
      this.user.lastName == null ||
      this.user.lastName == ''||
      this.user.email == null ||
      this.user.email == ''||
      this.user.phone == null||
      this.user.phone == ''

    ) {
        //  alert('User is required !!');
        this.snack.open('Details are required !! ', '', { duration: 3000 });
        return;
      } else {
        this.snack.open('succesfully Registered !! ', '', { duration: 3000 });
      }

  this.userService.addUser(this.user).subscribe(
    (data: any) => {
      //success
      console.log(data);
      //alert('success');
      Swal.fire('Successfully done !!', 'User id is ' + data.id, 'success');
    },
    (error) => {
      //error
      console.log(error);
      // alert('something went wrong');
      this.snack.open(error.error.text, '', {
        duration: 3000,
      });
    }
  );
}
}
